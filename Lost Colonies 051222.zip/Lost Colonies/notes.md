﻿LA TECHNO
=========
C#/Monogame

LE JEU
======
On explore l'infini (Elite, Millennium 2.2, FTL).
- Génération procédurale de planètes (noms, type, ressources, etc.) dans des secteurs/galaxies.
https://wiki.alioth.net/index.php/Classic_Elite_planet_descriptions
On a des biotopes/types de planêtes (sable/Dune, Stargate, No man sky).
- Gaz
- Sable
- Organique
- Glace
- Lave
On survole la surface (Frontier FE) à la recherche de...
On explore des Donjons : Colonies sousterraines (Fallout, Cogmind, Desktop Dungeon)
On a des robots complémentaires (Codmind, Quadralien).
- Combat
- Hacker
- Tank
On des puzzles (Sokoban, Chip's Challenge, Link Awakening).
Le décor est destructible (Forget Me Not, Broforce)
On a des monstres en fonction du biotope.
On sauve des gens (Alien Syndrome).
Le monde est généré prodécuralement.
On peut s'échanger des clés. Une clé = un monde.

LES INSPIRATIONS MEMBRES
========================
Dome Keeper
Neurovoider
Void Expanse
Metal Mind
Dungeon of the Endless

Tour par tour
=============
** Rogue's Tale
Cogmind
Fallout Classic
XCOM
Space Hulk Tactic
Mario et Lapin Crétin
Final Fantasy Tactic
Advance War
Jagged Alliance
Phoenix point
Phantom Doctrine
Shining Force
** https://archrebel.blogspot.com/ (fantastique effet de grenade)

---
#Devlog : 

##Episode 1 (17/10/22):
Debrief, feature list, inspirations

##Episode 2 (24/10/22):
On a importé et adapté le framework du projet de ma LD36.
Ajouté un Service Locator.
Créé 2 scène : menu et test.

##Episode 3 (31/10/22):
Générateur de noms de planètes.
"..LEXEGEZACEBISOUSESARMAINDIREA.ERATENBERALAVETIEDORQUANTEISRION"
https://github.com/fragglet/txtelite/blob/master/txtelite.c

##Episode 4 (7/11/22)
Générateur de galaxie
Scene d'affichage de la galaxie avec le sélecteur de planète

##Episode 5 (14/11/22)
Chemin de fer

##Episode 6 (21/11/22)
Migrer le Control Manager au niveau du GameState
Splash Screen
Menu et musique (affichage synchro avec la musique)

##Episode 7 (28/11/22)
Cinématique de sortie du vaisseau mère
Création d'un GameState avec le générateur de galaxie
Uniformiser les contrôles (au lieu que chaque scène ait les siens)

##Episode 8 (05/12/22)
AssetManager

##Episode 9 (12/12/22)
Tweening

