﻿
using var game = new Lost_Colonies.GameLost();
game.Run();
